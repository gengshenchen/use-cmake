/* #undef HAVE_POW */
#define demo_VERSION_MAJOR 3
#define demo_VERSION_MINOR 8
